import sqlite3

# ---------- DATABASE CONNECTION ----------
def connect():
    return sqlite3.connect("bank.db")

# ---------- CREATE TABLES ----------
def create_tables():
    conn = connect()
    cursor = conn.cursor()

    cursor.execute("""
    CREATE TABLE IF NOT EXISTS accounts(
        acc_no INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT,
        balance REAL
    )
    """)

    cursor.execute("""
    CREATE TABLE IF NOT EXISTS transactions(
        trans_id INTEGER PRIMARY KEY AUTOINCREMENT,
        acc_no INTEGER,
        type TEXT,
        amount REAL
    )
    """)

    conn.commit()
    conn.close()

create_tables()

# ---------- CREATE ACCOUNT ----------
def create_account():
    name = input("Enter your name: ")
    balance = float(input("Enter initial balance: "))

    conn = connect()
    cursor = conn.cursor()

    cursor.execute("INSERT INTO accounts(name, balance) VALUES(?, ?)", (name, balance))
    conn.commit()

    print("✅ Account created successfully!")
    conn.close()

# ---------- DEPOSIT ----------
def deposit():
    acc = int(input("Enter account number: "))
    amount = float(input("Enter amount to deposit: "))

    conn = connect()
    cursor = conn.cursor()

    cursor.execute("UPDATE accounts SET balance = balance + ? WHERE acc_no = ?", (amount, acc))
    cursor.execute("INSERT INTO transactions(acc_no, type, amount) VALUES(?, 'Deposit', ?)", (acc, amount))

    conn.commit()
    print("✅ Amount deposited!")
    conn.close()

# ---------- WITHDRAW ----------
def withdraw():
    acc = int(input("Enter account number: "))
    amount = float(input("Enter amount to withdraw: "))

    conn = connect()
    cursor = conn.cursor()

    cursor.execute("SELECT balance FROM accounts WHERE acc_no = ?", (acc,))
    result = cursor.fetchone()

    if result and result[0] >= amount:
        cursor.execute("UPDATE accounts SET balance = balance - ? WHERE acc_no = ?", (amount, acc))
        cursor.execute("INSERT INTO transactions(acc_no, type, amount) VALUES(?, 'Withdraw', ?)", (acc, amount))
        conn.commit()
        print("✅ Withdrawal successful!")
    else:
        print("❌ Insufficient balance or invalid account!")

    conn.close()

# ---------- CHECK BALANCE ----------
def check_balance():
    acc = int(input("Enter account number: "))

    conn = connect()
    cursor = conn.cursor()

    cursor.execute("SELECT name, balance FROM accounts WHERE acc_no = ?", (acc,))
    result = cursor.fetchone()

    if result:
        print(f"👤 Name: {result[0]}")
        print(f"💰 Balance: {result[1]}")
    else:
        print("❌ Account not found!")

    conn.close()

# ---------- TRANSACTION HISTORY ----------
def transaction_history():
    acc = int(input("Enter account number: "))

    conn = connect()
    cursor = conn.cursor()

    cursor.execute("SELECT type, amount FROM transactions WHERE acc_no = ?", (acc,))
    rows = cursor.fetchall()

    if rows:
        print("\n📜 Transaction History:")
        for row in rows:
            print(f"{row[0]} - {row[1]}")
    else:
        print("No transactions found.")

    conn.close()

# ---------- MAIN MENU ----------
def menu():
    while True:
        print("\n====== BANK SYSTEM ======")
        print("1. Create Account")
        print("2. Deposit")
        print("3. Withdraw")
        print("4. Check Balance")
        print("5. Transaction History")
        print("6. Exit")

        choice = input("Enter choice: ")

        if choice == '1':
            create_account()
        elif choice == '2':
            deposit()
        elif choice == '3':
            withdraw()
        elif choice == '4':
            check_balance()
        elif choice == '5':
            transaction_history()
        elif choice == '6':
            print("Thank you for using the system!")
            break
        else:
            print("Invalid choice!")

# ---------- RUN PROGRAM ----------
menu()
